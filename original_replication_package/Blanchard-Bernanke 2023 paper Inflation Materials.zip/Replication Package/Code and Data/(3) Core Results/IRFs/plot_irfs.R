# The following file generates plots of the IRFs in Bernanke Blanchard.  

# Import packages
library(tidyverse)
library(magrittr)
library(ggplot2)
library(zoo)
library(tseries)
library(readxl)
library(grid)
library(lubridate)
library(reshape2)

# Change WD
setwd("../Replication Package/Code and Data/(3) Core Results/IRFs/Output Data/")

# Plot IRFs
irf_energy <- read_excel("results_energy.xls")
irf_food <- read_excel("results_food.xls")
irf_shortage <- read_excel("results_shortage.xls")
irf_vu <- read_excel("results_vu.xls")

irf_data <- bind_cols(irf_energy$period, irf_energy$gcpi_simul, irf_food$gcpi_simul, irf_shortage$gcpi_simul)

irf_data %<>%
  rename(
    period = "...1", 
    energy = "...2",
    food = "...3", 
    shortage = "...4"
  ) %<>%
  filter(
    period >= 5 & period <= 20
  )

rm(irf_energy, irf_food, irf_shortage)

# Figure 10
plot1 <- ggplot(data = irf_data) +
  labs(title = "Figure 10. RESPONSES OF INFLATION TO SHOCKS TO THE RELATIVE PRICE \nOF ENERGY, THE RELATIVE PRICE OF FOOD, AND THE SHORTAGE INDEX", x = "Quarter", y = "Percent") + 
  geom_line(mapping = aes(x = 1:nrow(irf_data), y = energy, color = "Energy Prices"), linewidth = 1.25) +
  geom_line(mapping = aes(x = 1:nrow(irf_data), y = food, color = "Food Prices"), linewidth = 1.25) +
  geom_line(mapping = aes(x = 1:nrow(irf_data), y = shortage, color = "Shortages"), linewidth = 1.25) +
  scale_colour_manual("", 
                      breaks = c("Energy Prices", "Food Prices", "Shortages"),
                      values = c("blue", "red", "orange")) +
  theme_bw() + theme(legend.position = "bottom",
                     # legend.key.size = unit(3, 'cm'), #change legend key size
                     legend.key.height = unit(.47, 'cm'), #change legend key height
                     legend.key.width = unit(2, 'cm'), #change legend key width
                     legend.text = element_text(size=12), # change legend key font size
                     legend.background = element_rect(colour = 'black', fill = 'white', linetype='solid'),
                     legend.title = element_text(angle = 90, hjust = .5, vjust = 0.5),
                     plot.title = element_text(size=17.5),
                     panel.grid.major.x = element_blank(),
                     panel.grid.minor.x = element_blank(),
                     panel.grid.minor.y = element_blank(),
                     axis.line = element_line("black"),
                     axis.title.x = element_text(size = 16),
                     axis.title.y = element_text(size = 16),
                     axis.text.x = element_text(size=16, color = "black"),
                     axis.text.y = element_text(size=16, color = "black"),
                     panel.border = element_blank(), 
                     plot.caption = element_text(hjust = 0),
  ) + coord_fixed(ratio = 2) +
  scale_x_continuous(expand = c(.05, .02), breaks = seq(from = 1, to = 16, by = 1)) +
  scale_y_continuous(expand = c(.05, .02), breaks = seq(from = -.5, to = 2.5, by = .5))

ggsave(plot1)
# Figure 11
irf_vu %<>%
  filter(
    period >= 5 & period <= 20
  )

plot2 <- ggplot(data = irf_vu) +
  labs(title = "Figure 11. RESPONSE OF INFLATION TO SHOCKS TO THE VACANCY TO\nUNEMPLOYMENT RATIO.", x = "Quarter", y = "Percent") + 
  geom_line(mapping = aes(x = 1:nrow(irf_vu), y = gcpi_simul, color = "VU"), linewidth = 1.25) +
  scale_colour_manual("", 
                      breaks = c("VU"),
                      values = c("blue")) +
  theme_bw() + theme(plot.title = element_text(size=17.5),
                     panel.grid.major.x = element_blank(),
                     panel.grid.minor.x = element_blank(),
                     panel.grid.minor.y = element_blank(),
                     axis.line = element_line("black"),
                     axis.title.x = element_text(size = 16),
                     axis.title.y = element_text(size = 16),
                     axis.text.x = element_text(size=16, color = "black"),
                     axis.text.y = element_text(size=16, color = "black"),
                     panel.border = element_blank(), 
                     plot.caption = element_text(hjust = 0),
                     legend.position="none"
  ) + coord_fixed(ratio = 4) +
  scale_x_continuous(expand = c(.05, .02), breaks = seq(from = 1, to = 16, by = 1)) +
  scale_y_continuous(expand = c(.05, .02), breaks = seq(from = 0.0, to = 2.0, by = .2))

ggsave(plot2)

rm(irf_data, irf_vu)
